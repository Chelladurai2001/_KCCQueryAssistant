from sentence_transformers import SentenceTransformer
import pandas as pd
import chromadb

def generate_embeddings():
    df = pd.read_csv('data/processed/kcc_cleaned.csv')
    model = SentenceTransformer('sentence-transformers/all-mpnet-base-v2')

    client = chromadb.PersistentClient(path='embeddings/vector_db')
    collection = client.get_or_create_collection("kcc_data")

    for i, row in df.iterrows():
        embedding = model.encode(row['question'] + " " + row['answer'])
        metadata = {'id': str(i), 'question': row['question']}
        collection.add(documents=[row['answer']], embeddings=[embedding.tolist()], ids=[str(i)], metadatas=[metadata])

    print("Embeddings generated and stored in ChromaDB.")

if __name__ == "__main__":
    generate_embeddings()