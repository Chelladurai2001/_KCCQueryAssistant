import chromadb
import ollama
import numpy as np

def query_kcc(query, top_k=3, threshold=0.4):
    client = chromadb.PersistentClient(path='embeddings/vector_db')
    collection = client.get_collection("kcc_data")

    results = collection.query(query_texts=[query], n_results=top_k)
    scores = results['distances'][0]

    if scores and min(scores) < threshold:
        context = "\n".join(results['documents'][0])
        prompt = f"Use the following KCC data to answer:\n{context}\n\nQuestion: {query}"
        response = ollama.chat(model='gemma', messages=[{'role': 'user', 'content': prompt}])
        return response['message']['content'], context
    else:
        return None, None

if __name__ == "__main__":
    query = "What pest-control methods are recommended for paddy in Tamil Nadu?"
    answer, context = query_kcc(query)
    if answer:
        print("KCC Answer:", answer)
    else:
        print("No local context found. Please use live internet search.")