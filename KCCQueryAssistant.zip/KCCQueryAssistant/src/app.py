import streamlit as st
from rag_pipeline import query_kcc

st.title("KCC Query Assistant")
st.write("Ask your agricultural questions below.")

query = st.text_input("Enter your query:")
if st.button("Get Answer"):
    if query:
        answer, context = query_kcc(query)
        if answer:
            st.success("KCC Answer:")
            st.markdown(answer)
            st.markdown(f"**Context Source:**\n{context}")
        else:
            st.warning("No local context found. Fallback to live internet search is recommended.")