import pandas as pd
import os

def load_kcc_data(path):
    df = pd.read_csv(path)
    print(f"Loaded {len(df)} records.")
    return df

def clean_and_preprocess(df):
    df = df.dropna(subset=['Question', 'Answer'])
    df = df.rename(columns=str.lower)
    df['question'] = df['question'].str.strip()
    df['answer'] = df['answer'].str.strip()
    return df

def chunk_data(df, output_dir='data/processed'):
    os.makedirs(output_dir, exist_ok=True)
    df.to_csv(os.path.join(output_dir, 'kcc_cleaned.csv'), index=False)
    print(f"Processed data saved to {output_dir}.")

if __name__ == "__main__":
    raw_path = 'data/raw/KCC_Dataset.csv'
    df = load_kcc_data(raw_path)
    df_cleaned = clean_and_preprocess(df)
    chunk_data(df_cleaned)