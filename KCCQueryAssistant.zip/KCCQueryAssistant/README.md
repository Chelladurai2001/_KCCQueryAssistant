# KCC Query Assistant

An offline-capable AI app that allows users to query agricultural advice from the Kisan Call Center (KCC) dataset.

## Setup

1. Clone the repo:
   ```
   git clone <your-repo-link>
   cd YourName_KCCQueryAssistant
   ```

2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Pull the model for Ollama:
   ```
   ollama pull gemma
   ```

4. Run the app:
   ```
   streamlit run app.py
   ```

## Project Structure
- `data/`: Raw and processed data files.
- `src/`: Source code.
- `embeddings/`: Vector store files.
- `requirements.txt`: Dependencies.
- `README.md`: Project guide.

## Demo Video
[Insert Google Drive link here]

## Sample Queries
- What pest-control methods are recommended for paddy in Tamil Nadu?
- How to manage drought stress in groundnut cultivation?
- ...